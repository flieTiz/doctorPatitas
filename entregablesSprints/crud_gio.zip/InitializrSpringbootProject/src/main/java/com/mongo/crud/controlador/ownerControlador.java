package com.mongo.crud.controlador;

import com.mongo.crud.modelo.ownerModelo;
import com.mongo.crud.vista.ownerVista;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;




@RestController
@CrossOrigin(origins = "*",methods = {RequestMethod.POST,RequestMethod.GET,RequestMethod.DELETE,RequestMethod.PUT})
@RequestMapping("/api/owner")

public class ownerControlador {
    
    @Autowired
    private ownerVista user;
    
    ////////Procedimiento guardado general
    @PostMapping("/guardar")
    public ownerModelo saveOwners(@Validated @RequestBody ownerModelo varU){
            return user.insert(varU);
    }
    
    ////////Procedimiento consulta general
    @GetMapping("/consultar")
    public List<ownerModelo> colsultOwner(){

        return user.findAll();

    }

    //////////Procedimiento actualizar info
    @PutMapping("/actualizar/{id}")
    public ownerModelo actualizarUsuarios(@PathVariable String id, @Validated @RequestBody ownerModelo varU){

        return user.save(varU);

    }

    ///////////Procedimiento eliminar usuario
    @DeleteMapping("/eliminar{id}")
    public void eliminarusuarios(@PathVariable String id){

        user.deleteById(id);

    }
    
}
